<footer>
  <div class="page-min-width-container clearfix">
      <div class="hotline float-left">
        86-21-51876629(个人)<br>
        86-21-51088480(企业)
      </div>
      <div class="hotlink float-right row">
        <?php html5_get_footer_nav("页尾导航菜单"); ?>
        <div class="col-xs-2">
          <a href="#" class="appcode">德盛跳了吧APP</a>
        </div>
      </div>
  </div>
    <div class="copyright">©<?php echo date('Y'); ?> 德盛人才-白领推荐专业品牌 　 沪ICP备12017297号-2</div>
</footer>

<script src="<?php echo get_template_directory_uri(); ?>/resource/min_js/jquery-1.9.1.min.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/resource/min_js/bootstrap.min.js"></script>

<script>
  $(document).ready(function(e) {
    $(".menu-item-has-children").hover(function(e) {
      $(this).addClass("active").children(".sub-menu").show().hover(function(e) { $(this).show().prev("a").addClass("active");}, function(e) { $(this).hide().prev("a").removeClass("active"); });
    }, function(e) {
      $(this).removeClass("active").children(".sub-menu").hide();
    });
  });
</script>
<script src="<?php echo get_template_directory_uri(); ?>/resource/plugin/slick/slick.min.js"></script>
<script>
  $(document).ready(function(e) {
    $('.banner-slider').slick({
      dots: true,
      infinite: true,
      speed: 500,
      cssEase: 'linear',
      prevArrow: '<a class="left-btn" href="javascript:void(0);"></a>',
      nextArrow: '<a class="right-btn" href="javascript:void(0);"></a>'
    });
    $('.feature-container li a').mouseenter(function(e) {
      $(this).animate({marginTop: "-30px"}, 100);
    });
    $('.feature-container li a').mouseleave(function(e) {
      $(this).animate({marginTop: "0px"}, 100);
    });
    $("#download-app-switch").click(function(e) {
      if($(".floater-download-app").css("right")!= "0px")
        $(".floater-download-app").animate({right: "0px"}, "slow");
      else
        $(".floater-download-app").animate({right: "-205px"}, "slow");
      return(false);
    });
  });
</script>
<script charset="utf-8" type="text/javascript" src="http://wpa.b.qq.com/cgi/wpa.php?key=XzkzODAxNDg2Nl8xNDk3MDNfNDAwMDA1MTU2Nl8"></script>
</body>
</html>