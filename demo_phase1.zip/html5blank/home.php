<?php get_header(); ?>

<?php
/*
$args = array(
  'post_type' => 'attachment'
);

query_posts($args);
// 循环
$idx = 0;
while ( have_posts() ) : the_post();
  the_title();
endwhile;

// 重置查询
wp_reset_query();

$the_query = new WP_Query($args);  //无需这句，不然翻页失效

// 循环
$idx = 0;
while ( $the_query -> have_posts() ) : $the_query -> the_post();
  echo $idx++." ".get_the_title();
endwhile;
 
// 重置查询
wp_reset_postdata();
*/

?>
<div class="banner-slider">
  <div><img name="pchome_r2_c1" src="<?php echo get_template_directory_uri(); ?>/resource/images/pc-home_r2_c1.jpg" alt=""></div>
  <div><img name="pchome_r2_c1" src="<?php echo get_template_directory_uri(); ?>/resource/images/pc-home_r2_c1.jpg" alt=""></div>
  <div><img name="pchome_r2_c1" src="<?php echo get_template_directory_uri(); ?>/resource/images/pc-home_r2_c1.jpg" alt=""></div>
</div>
<div class="feature-container">
  <ul class="block-list clearfix">
    <li><a href="#" class="recommend" title="白领人才推荐"><div><p class="vertical-align-box"><span>白领人才推荐&nbsp;</span></p></div></a></li>
    <li><a href="#" class="evaluating active" title="人才测评"><div><p class="vertical-align-box"><span>人才测评&nbsp;</span></p></div></a></li>
    <li><a href="#" class="salary-management" title="薪酬管理及公司成立服务"><div><p class="vertical-align-box"><span>薪酬管理及</span><br><span>公司成立服务&nbsp;</span></p></div></a></li>
    <li><a href="#" class="employee-service" title="通用类人才灵活雇佣服务"><div><p class="vertical-align-box"><span>通用类人才</span><br><span>灵活雇佣服务&nbsp;</span></p></div></a></li>
    <li><a href="#" class="employee-card" title="工作签证申办"><div><p class="vertical-align-box"><span>工作签证申办&nbsp;</span></p></div></a></li>
  </ul>
</div>
<div class="home-about">
  <div class="paragraph">
    <h1>关于德盛</h1>
  　　德盛是上海道生智企业管理顾问有限公司(人才中介机构服务许可证：449)旗下专业白领推荐品牌，已注册商标。道生智创立于2002年，是由上海市人事局批准的专业从事中高人才咨询服务的中介机构。目前旗下有两大品牌，面向企业提供中高级猎头服务的道生智品牌，和面向白领求职者提供优质工作机会的德盛品牌。<br>
  　　我们优质迅捷的服务目前已赢得4500多家企业的认可，并与企业HR建立了长期良好的合作关系，合作企业每年以15%的速度递增。外资企业占60%。
    <p class="clearfix"><a href="#" class="button-outline white float-right" title="了解更多">了解更多</a></p>
  </div>
</div>
<div class="home-content">
  <div class="paragraph">
    <h1>服务范围</h1>
  　　<strong class="text-green">对于企业</strong>：大批量财务类、人力资源类、行政类、物流类、外贸类、采购类、市场类、销售类、IT类、技术类等岗位的白领人才汇聚德盛。为企业提供优秀庞大的人才库资源，专业的白领人才推荐顾问是您得力的招聘助手，更快捷、精准的为您匹配、筛选出最适合的优秀人才。<br>
  　　<strong class="text-green">对于个人</strong>：众多企业在消费品业、物流业、外贸业、生产制造业、IT电子业、服装业、金融业、房地产业、汽车等行业有着广泛的影响。最强大的HR人脉网络，第一时间截获最新最优质的职位信息，过滤企业的招聘计划，为各类人才提供更多、更优质的职业机会。
  </div>
</div>

<?php get_footer(); ?>
