<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :'; } ?> <?php bloginfo('name'); ?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<meta content="width=device-width, initial-scale=1" name="viewport">
<meta content="<?php bloginfo('description'); ?>" name="description">
<meta content="" name="author">
<script src="<?php echo get_template_directory_uri(); ?>/resource/js/h5forie.js"></script>
<link href="<?php echo get_template_directory_uri(); ?>/resource/min_css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/resource/min_css/default.min.css" type="text/css" >
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/resource/min_css/ds_pc.min.css" type="text/css" >
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/resource/plugin/slick/slick.css"/>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/resource/plugin/slick/slick-theme.css"/>
</head>
<body <?php body_class('ds-pc'); ?>>
<div class="floater-download-app" title="下载德盛人才移动端APP应用‘跳了吧’">
  <img src="<?php echo get_template_directory_uri(); ?>/resource/images/app_download.png" alt="" usemap="#Map">
  <map name="Map">
    <area shape="rect" coords="79,180,227,217" href="#" id="download-ios">
    <area shape="rect" coords="78,235,227,272" href="#" id="download-and">
    <area shape="rect" coords="5,13,51,168" href="#" id="download-app-switch">
  </map>
</div>
<header>
    <nav class="row page-min-width-container">
      <div class="logo-block float-left">
        <div class="row language-switch">
          <!--a href="index.html" class="col-xs-3 chinese" title="中文版">中文 |</a>
          <a href="#" class="col-xs-4 english" title="English">English</a>
          <a href="#" class="col-xs-5 management" title="后台登陆">后台登陆</a-->
        </div>
        <a href="<?php echo home_url(); ?>" class="logo" title="德盛人才首页"></a>
      </div>
      <?php html5blank_nav(); ?>
  </nav>
  </header>